(function(){
    var myvar = "hello, world!";
    console.log(myvar);
})();
