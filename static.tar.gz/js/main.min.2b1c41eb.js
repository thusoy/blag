!function(){var a="hello, world!";console.log(a)}();
//# sourceMappingURL=/static/js/main.min.map